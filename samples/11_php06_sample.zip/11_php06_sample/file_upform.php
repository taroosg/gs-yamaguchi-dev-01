<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ファイルアップロード練習</title>
</head>

<body>
  <form>
    <fieldset>
      <legend>ファイルアップロード</legend>
      <div>
        <input type="file">
      </div>
      <div>
        <button>submit</button>
      </div>
    </fieldset>
  </form>

</body>

</html>