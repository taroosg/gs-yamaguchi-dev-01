<?php
// sessionをスタートしてidを再生成しよう．
// 旧idと新idを表示しよう．
